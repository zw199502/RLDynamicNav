#include "pub_rl_state.h"


VelodyneLaserScan::VelodyneLaserScan(ros::NodeHandle &nh) : nh_(nh)
{
  // consecutive 10 Lidar scans
  // the sampling frequency of lidar is 10Hz, the time of consecutive 10 Lidar scans is 0.9 second.
  ElevenLidarScansEndPositionWorldX.assign(((SCAN_INTERVAL * 3 + 1) * SIZE), MAX_DIST);
  ElevenLidarScansEndPositionWorldY.assign(((SCAN_INTERVAL * 3 + 1) * SIZE), MAX_DIST);
  Odom_sub_  = new message_filters::Subscriber<nav_msgs::Odometry>(nh_, "/odom", 20);
  Lidar_sub_ = new message_filters::Subscriber<sensor_msgs::LaserScan>(nh_, "/scan", 2);
  sync_ = new message_filters::Synchronizer<SyncPolicy>(SyncPolicy(10), *Odom_sub_, *Lidar_sub_);
  sync_->registerCallback(boost::bind(&VelodyneLaserScan::combineCallback,this,_1,_2));
  pub_RL_states = nh_.advertise<std_msgs::Float32MultiArray>( "/RL_states", 10);
  pub_scan = nh_.advertise<sensor_msgs::LaserScan>("/scan", 10);
}

void VelodyneLaserScan::combineCallback(const nav_msgs::Odometry::ConstPtr& msg1, const sensor_msgs::LaserScan::ConstPtr& msg2){
  //msg1: Lhip   msg2: Rhip
  float q_0, q_1, q_2, q_3;
  float yaw = 0.0, pitch = 0.0, roll = 0.0;
  q_0 = msg1->pose.pose.orientation.w;
  q_1 = msg1->pose.pose.orientation.x;
  q_2 = msg1->pose.pose.orientation.y;
  q_3 = msg1->pose.pose.orientation.z;
  // roll = atan2f(2.0 * (q_0 * q_1 + q_2 * q_3), 1.0 - 2.0 * (q_1 * q_1 + q_2 * q_2));
  // pitch = asinf(2.0 * (q_0 * q_2 - q_1 * q_3));
  yaw = atan2f(2.0 * (q_0 * q_3 + q_1 * q_2), 1.0 - 2.0 * (q_2 * q_2 + q_3 * q_3));
  robot_pose_world[0] = msg1->pose.pose.position.x;
  robot_pose_world[1] = msg1->pose.pose.position.y;
  robot_pose_world[2] = yaw;
  // publish scan and rl_states
  pub_scan_and_RL_states(msg2);
}

void VelodyneLaserScan::pub_scan_and_RL_states(const sensor_msgs::LaserScan::ConstPtr& msg)
{ 
  vector<float> x_array(SIZE, MAX_DIST);
  vector<float> y_array(SIZE, MAX_DIST);
  float angle_laser = 0.0;
  for(int i = 0; i < SIZE; i++){
    angle_laser = (i - SIZE + 0.5) * RESOLUTION + M_PI_S;
    x_array[i] = msg->ranges[i] * cosf(angle_laser);
    y_array[i] = msg->ranges[i] * sinf(angle_laser);
  }
    
  for(int k = 0; k < SIZE; k++){
    float x_lidar_to_world = MAX_DIST, y_lidar_to_world = MAX_DIST;
    if ((x_array[k] < (MAX_DIST - 1.0)) && (y_array[k] < (MAX_DIST - 1.0))){
      y_lidar_to_world = robot_pose_world[1] + x_array[k] * sinf(robot_pose_world[2]) + y_array[k] * cosf(robot_pose_world[2]);
      x_lidar_to_world = robot_pose_world[0] + x_array[k] * cosf(robot_pose_world[2]) - y_array[k] * sinf(robot_pose_world[2]);
    }
    ElevenLidarScansEndPositionWorldX.erase(ElevenLidarScansEndPositionWorldX.begin());
    ElevenLidarScansEndPositionWorldX.push_back(x_lidar_to_world);
    ElevenLidarScansEndPositionWorldY.erase(ElevenLidarScansEndPositionWorldY.begin());
    ElevenLidarScansEndPositionWorldY.push_back(y_lidar_to_world);
  }
  std_msgs::Float32MultiArray RL_states;
  // four lidar scans (SIZE * 4), goal position (2) related to the robot, robot pose (3) in the world frame
  RL_states.data.resize(SIZE * 4 + 5);
  for(int m = 0; m < 4; m++){
    vector<float> scan_tmp(SIZE, MAX_SCAN);
    for(int n = 0; n < SIZE; n++){
      float x_tmp, y_tmp, scan_x, scan_y;
      int index_tmp;
      x_tmp = ElevenLidarScansEndPositionWorldX[SCAN_INTERVAL * (4 - 1 - m) * SIZE + (SIZE - 1 - n)];
      y_tmp = ElevenLidarScansEndPositionWorldY[SCAN_INTERVAL * (4 - 1 - m) * SIZE + (SIZE - 1 - n)];
      scan_x = x_tmp - robot_pose_world[0];
      scan_y = y_tmp - robot_pose_world[1];
      index_tmp = (atan2f(scan_y, scan_x) + M_PI_S) / RESOLUTION;
      if ((index_tmp >=0) && (index_tmp < SIZE)){
        scan_tmp[index_tmp] = hypotf(scan_x, scan_y);
      }
    }
    for(int p = 0; p < SIZE; p ++){
      if(scan_tmp[p] > MAX_SCAN){
        scan_tmp[p] = MAX_SCAN;
      }
      else{
        if(scan_tmp[p] < MIN_SCAN){
          scan_tmp[p] = MIN_SCAN;
        }
      }
      RL_states.data[m * SIZE + p] = scan_tmp[p] / MAX_SCAN;
    }
  }
  float goal_x_to_robot, goal_y_to_robot;
  goal_y_to_robot = goal_position[1] - robot_pose_world[1];
  goal_x_to_robot = goal_position[0] - robot_pose_world[0];
  RL_states.data[SIZE * 4 + 0] = hypotf(goal_y_to_robot, goal_x_to_robot) / 6.0;
  RL_states.data[SIZE * 4 + 1] = atan2f(goal_y_to_robot, goal_x_to_robot) / M_PI_S;
  RL_states.data[SIZE * 4 + 2] = robot_pose_world[0];
  RL_states.data[SIZE * 4 + 3] = robot_pose_world[1];
  RL_states.data[SIZE * 4 + 4] = robot_pose_world[2];
  count ++;
  if (count % SCAN_INTERVAL == 0){   // publish LR_states every (SCAN_INTERVAL*0.1) second
    pub_RL_states.publish(RL_states);
    // double secs =ros::Time::now().toSec();
    // ROS_INFO("x: %.4f, y: %.4f, yaw: %.4f, goal_x: %.4f, goal_y: %.4f", robot_pose_world[0], robot_pose_world[1], robot_pose_world[2], 
    //         goal_x_to_robot, goal_y_to_robot);
  }
}


int main(int argc, char **argv){ /** The arguments to main are the means by which a system outside scope 
and understanding of your program can configure your program to do a particular task. These are command line parameters.**/

  ros::init(argc, argv, "rl_environment"); // node name, can be superseded by node name in the launch file
  ros::NodeHandle nh;
  VelodyneLaserScan myNode(nh); 
  ros::Duration(0.1).sleep();
  //ros::spin(); // only need for subscriber to call its callback function (Does not need for Publisher).
  // ros::MultiThreadedSpinner spinner(5); // Use 5 threads for 5 callbacks in parallel
  // spinner.spin(); // spin() will not return until the node has been shutdown

  ros::AsyncSpinner async_spinner(2);
  async_spinner.start();
  ros::waitForShutdown();

  return 0;

} // end of main

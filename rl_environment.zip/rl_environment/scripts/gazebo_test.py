
import numpy as np
import tensorflow as tf
from lidar_dqn import Lidar_DQN
import rospy
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import threading
from crowd_env import Env
import sys
from math import atan2, fabs, pi, hypot, cos, sin

tf.keras.backend.set_floatx('float32')
lidar_dim = 1800
n_lidar = 4
position_dim = 2


def MotionControl(msg):
    global waypoint_position_odom_x, waypoint_position_odom_y
    # in odom frame
    x_odom = msg.pose.pose.position.x
    y_odom = msg.pose.pose.position.y
    q_0 = msg.pose.pose.orientation.w
    q_1 = msg.pose.pose.orientation.x
    q_2 = msg.pose.pose.orientation.y
    q_3 = msg.pose.pose.orientation.z
    yaw_odom = atan2(2.0 * (q_0 * q_3 + q_1 * q_2), 1.0 - 2.0 * (q_2 * q_2 + q_3 * q_3))

    ########## follow the carrot ############
    target_angle = atan2(waypoint_position_odom_y - y_odom, waypoint_position_odom_x - x_odom)
    target_distance = hypot(waypoint_position_odom_y - y_odom, waypoint_position_odom_x - x_odom)
    delta_angle = target_angle - yaw_odom
    if delta_angle > pi:
        delta_angle = delta_angle - 2.0 * pi
    elif delta_angle < -pi:
        delta_angle = delta_angle + 2.0 * pi
    linear_v = 0.0
    angular_v = 0.0
    
    angular_v = angle_to_angular_v * delta_angle
    if angular_v > angular_v_max:
        angular_v = angular_v_max
    elif angular_v < -angular_v_max:
        angular_v = -angular_v_max
    if fabs(delta_angle) <= pi / 3.0 and fabs(delta_angle) > pi / 5.0:
        linear_v = linear_v_max / 3.0
    elif fabs(delta_angle) <= pi / 5.0 and fabs(delta_angle) > pi / 7.0:
        linear_v = linear_v_max / 2.0
    elif fabs(delta_angle) <= pi / 7.0:
        linear_v = linear_v_max
    if target_distance < 0.02:
        linear_v = 0.0
        angular_v = 0.0
    ########## follow the carrot ############

    vel_cmd = Twist()
    vel_cmd.linear.x = linear_v
    vel_cmd.angular.z = angular_v
    pub_cmd_vel.publish(vel_cmd)

def StateCallback(msg):
    global lidar_data, goal_position, action_idx, waypoint_position_odom_x, waypoint_position_odom_y
    for i in range(lidar_dim * n_lidar):
        lidar_data[i] = msg.data[i]
    goal_position[0] = msg.data[lidar_dim * n_lidar + 0]
    goal_position[1] = msg.data[lidar_dim * n_lidar + 1]
    if goal_position[0] * 6.0 <= 0.3:
        print('goal arrived!')
        sys.exit(0)
    action_idx = target_policy.get_action(lidar_data, goal_position)
    odom_x = msg.data[lidar_dim * n_lidar + 2]
    odom_y = msg.data[lidar_dim * n_lidar + 3]
    odom_yaw = msg.data[lidar_dim * n_lidar + 4]
    dx = action_space[action_idx][1] * _env.time_step
    dy = -action_space[action_idx][0] * _env.time_step
    MotionControlLock.acquire()
    waypoint_position_odom_x = dx + odom_x
    waypoint_position_odom_y = dy + odom_y
    MotionControlLock.release()

    # if using differential mobile robot, please add comment
    robot_name = 'turtlebot3_burger'
    _env.model_state_req.model_state.model_name = robot_name
    _env.model_state_req.model_state.pose.position.x = waypoint_position_odom_x
    _env.model_state_req.model_state.pose.position.y = waypoint_position_odom_y
    #set models pos from world
    rospy.wait_for_service('/gazebo/set_model_state')
    try:
        _env.model_state_proxy(_env.model_state_req)
    except rospy.ServiceException:
        print('/gazebo/set_model_state call failed')
    # if using differential mobile robot, please add comment

def main():
    sub_robot_states = rospy.Subscriber('/RL_states', Float32MultiArray, StateCallback, queue_size=5)
    ## if using differential mobile robot, please remove the comment
    # sub_odom = rospy.Subscriber('/odom', Odometry, MotionControl, queue_size=20)

if __name__ == '__main__':
    rospy.init_node('rl_navigation_test')
    _env = Env()
    _env.reset()
    pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    v_sample_num = 7
    # allocate gpu
    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    gpu_index = 0
    tf.config.experimental.set_visible_devices(devices=gpus[gpu_index], device_type='GPU')
    # tf.config.experimental.set_virtual_device_configuration(gpus[gpu_index], \
    # [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=4096)])
    
    # policy --> map dqn
    target_policy = Lidar_DQN()
    model_weight_file = 'weight_episode_20000.h5'
    target_policy.configure(v_sample_num * v_sample_num) # square of a odd integer
    target_policy.load_model(model_weight_file)
    target_policy.set_lr()
    delta_v = 0.6 / (v_sample_num - 1) # speed from -0.3m/s to 0.3m/s
    v_sample = []
    for i in range(v_sample_num):
        v = -0.3 + delta_v * i
        v_sample.append(v)
    action_space = []
    for vx in v_sample:
        for vy in v_sample:
            action_space.append((vx, vy))
    action_idx = 0
    waypoint_position_odom_x = 0.0
    waypoint_position_odom_y = 0.0

    lidar_data = np.ones(lidar_dim * n_lidar, dtype=np.float32)
    goal_position = np.ones(position_dim, dtype=np.float32)
    linear_v_max = 0.5
    sample_linear = []
    for i in range(11):
        sample_linear.append(i * 0.05)    
    angular_v_max = 2.5
    sample_angular = []
    for i in range(51):
        sample_angular.append((i - 25) * 0.1)
    angle_to_angular_v = 1.5  # please tune it if using differential mobile robot
    distance_to_linear_v = 10.0
    MotionControlLock = threading.Lock()
    main()
    rospy.spin()
import rospy
import threading
from std_srvs.srv import Empty
from gazebo_msgs.srv import SpawnModel, DeleteModel

from gazebo_msgs.srv import SetModelState, SetModelStateRequest, GetModelState, GetModelStateRequest, SetModelConfiguration, SetModelConfigurationRequest
from gazebo_msgs.msg import ModelState

from geometry_msgs.msg import Pose
from std_srvs.srv import Empty


import time
import numpy as np

from orca import Orca
from obstacle import Obstacle
from state import *

# used for visualizing goal
goal_model_dir = '/home/zw/RL_navigation_dynamic/src/rl_environment/urdf/Target/model.sdf'
# used for visualizing goal

# obstacle number and the position offset of these obstacles
# these two variables should be modified according to the file worlds/dynamic_world.world
# you can define your own obstables in the file worlds/dynamic_world.world
obstacle_num = 4
obstacle_position_offset = [(2.0, -2.0), (1.0, 1.73), (3.0, 1.73), (2.5, -0.7)]
# obstacle number and the position offset of these obstacles

class Env:
    def __init__(self):
        # obstacle position
        self.obstacle_position = np.zeros((obstacle_num, 2), dtype=np.float32)
        # simulation time
        self.time_limit = 50.0
        # control period
        self.time_step = 0.3
        self.update_interval = 5
        self.rate_obstacle = rospy.Rate(1.0 / self.time_step * self.update_interval)
        #obstacles
        self.obstacles = None
        # whether to randomize the obstacle attributes or not
        self.randomize_attributes = False
        self.circle_radius = 2.0

        # used to set obstacle position      
        self.model_state_proxy = rospy.ServiceProxy('/gazebo/set_model_state',SetModelState)
        self.model_state_req = SetModelStateRequest()
        self.model_state_req.model_state = ModelState()
        self.model_state_req.model_state.model_name = 'turtlebot3_burger'
        self.model_state_req.model_state.pose.position.x = 0.0
        self.model_state_req.model_state.pose.position.y = 0.0
        self.model_state_req.model_state.pose.position.z = 0.0
        self.model_state_req.model_state.pose.orientation.x = 0.0
        self.model_state_req.model_state.pose.orientation.y = 0.0
        self.model_state_req.model_state.pose.orientation.z = 0.0
        self.model_state_req.model_state.pose.orientation.w = 1.0   
        self.model_state_req.model_state.twist.linear.x = 0.0
        self.model_state_req.model_state.twist.linear.y = 0.0
        self.model_state_req.model_state.twist.linear.z = 0.0
        self.model_state_req.model_state.twist.angular.x = 0.0
        self.model_state_req.model_state.twist.angular.y = 0.0
        self.model_state_req.model_state.twist.angular.z = 0.0
        self.model_state_req.model_state.reference_frame = 'world'  

        self.joint_name_lst = ['wheel_left_joint', 'wheel_right_joint']
        self.starting_pos = np.array([0.0, 0.0])
        self.model_config_proxy = rospy.ServiceProxy('/gazebo/set_model_configuration',SetModelConfiguration)
        self.model_config_req = SetModelConfigurationRequest()
        self.model_config_req.model_name = 'turtlebot3_burger'
        self.model_config_req.urdf_param_name = 'robot_description'
        self.model_config_req.joint_names = self.joint_name_lst
        self.model_config_req.joint_positions = self.starting_pos
        # used to reset robot state

        # used to pause and unpause simulation
        self.pause_proxy = rospy.ServiceProxy('/gazebo/pause_physics', Empty)
        self.unpause_proxy = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        # used to pause and unpause simulation

        # visualize goal in Gazebo
        self.goal = rospy.ServiceProxy('/gazebo/spawn_sdf_model', SpawnModel)
        self.goal_position_pose = Pose()
        # visualize goal in Gazebo
        
        # goal position, x, y
        self.goal_position = np.array([4.0, 0.0])

    def generate_obstacle_position(self):
        self.obstacles = []
        for i in range(obstacle_num):
            obstacle = Obstacle()
            obstacle.time_step = self.time_step
            obstacle.radius = 0.3
            obstacle.v_pref = 0.3
            py = -self.circle_radius + obstacle_position_offset[i][0]
            px = - obstacle_position_offset[i][1]
            obstacle.set(px, py, -px, -py, 0, 0, 0)
            self.obstacles.append(obstacle)
        for i in range(obstacle_num):
            obstacle_policy = Orca()
            obstacle_policy.time_step = self.time_step
            self.obstacles[i].set_policy(obstacle_policy)

    def reset_robot_state(self):
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.pause_proxy()
        except rospy.ServiceException:
            print('/gazebo/pause_physics service call failed')

        # Build the target
        rospy.wait_for_service('/gazebo/spawn_sdf_model')
        try:
            goal_urdf = open(goal_model_dir, "r").read()
            target = SpawnModel
            target.model_name = 'target'  # the same with sdf name
            target.model_xml = goal_urdf
            self.goal_position_pose.position.x = self.goal_position[0]
            self.goal_position_pose.position.y = self.goal_position[1]
            self.goal(target.model_name, target.model_xml, 'namespace', self.goal_position_pose, 'world')
        except (rospy.ServiceException) as e:
            print("/gazebo/failed to build the target")

        #set models pos from world
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.model_state_proxy(self.model_state_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_state call failed')

        #set model's joint config
        rospy.wait_for_service('/gazebo/set_model_configuration')
        try:
            self.model_config_proxy(self.model_config_req)
        except rospy.ServiceException:
            print('/gazebo/set_model_configuration call failed')
     
        #unpause physics
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.unpause_proxy()
        except rospy.ServiceException:
            print('/gazebo/unpause_physics service call failed')

    def reset(self):
        self.generate_obstacle_position()
        self.reset_robot_state()
        rospy.sleep(2.0)
        obstacle_motion = threading.Thread(target=self.obstacle_motion_thread)
        obstacle_motion.start()

    def obstacle_motion_thread(self):
        while not rospy.is_shutdown():
            obstacle_actions = []
            obstacls_position = []
            for obstacle in self.obstacles:
                # observation for obstacles is always coordinates
                ob = [other_obstacle.get_observable_state() for other_obstacle in self.obstacles if other_obstacle != obstacle]
                obstacle_actions.append(obstacle.act(ob))
            for i, obstacle_action in enumerate(obstacle_actions):
                obstacls_position.append((self.obstacles[i].px, self.obstacles[i].py))
                self.obstacles[i].update_states(obstacle_action)
            ## these two lines are used to keep one obstacle static
            # self.obstacles[2].px = 0
            # self.obstacles[2].py = -0.5
            dx = []
            dy = []
            for i in range(obstacle_num):
                dx.append((self.obstacles[i].px - obstacls_position[i][0]))
                dy.append((self.obstacles[i].py - obstacls_position[i][1]))
            for interval in range(self.update_interval):
                for i in range(obstacle_num):
                    obstacle_name = 'object' + str((i+1))
                    self.model_state_req.model_state.model_name = obstacle_name
                    x = obstacls_position[i][0] + (interval + 1) / self.update_interval * dx[i]
                    y = obstacls_position[i][1] + (interval + 1) / self.update_interval * dy[i]
                    x_trans = y + self.circle_radius - obstacle_position_offset[i][0]
                    y_trans = -x - obstacle_position_offset[i][1]
                    self.model_state_req.model_state.pose.position.x = x_trans
                    self.model_state_req.model_state.pose.position.y = y_trans
                    #set models pos from world
                    rospy.wait_for_service('/gazebo/set_model_state')
                    try:
                        self.model_state_proxy(self.model_state_req)
                    except rospy.ServiceException:
                        print('/gazebo/set_model_state call failed')
                self.rate_obstacle.sleep()
            for i, obstacle in enumerate(self.obstacles):
                # let humans move circularly from two points
                if obstacle.reached_destination():
                    self.obstacles[i].gx = -self.obstacles[i].gx
                    self.obstacles[i].gy = -self.obstacles[i].gy

# if __name__=='__main__':
#     rospy.init_node('rl_navigation')
#     _env = Env()
#     _env.reset()
#     obstacle_motion = threading.Thread(target=_env.obstacle_motion_thread)
#     obstacle_motion.start()
#     rospy.spin()
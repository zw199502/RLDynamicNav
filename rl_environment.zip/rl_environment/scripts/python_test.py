
import rospy
from std_msgs.msg import Float32MultiArray
rospy.init_node('python_test')
pub_cmd_vel = rospy.Publisher('/cmd_vel', Float32MultiArray, queue_size=10)
rate  = rospy.Rate(20)
while not rospy.is_shutdown():
    vel_cmd = Float32MultiArray(data=[0.0, 0.1])
    pub_cmd_vel.publish(vel_cmd)
    rate.sleep()
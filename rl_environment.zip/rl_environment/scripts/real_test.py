import numpy as np
import tensorflow as tf
from lidar_dqn import Lidar_DQN
import rospy
from std_msgs.msg import Float32MultiArray
from math import atan2, fabs, pi, hypot, cos, sin

tf.keras.backend.set_floatx('float32')
lidar_dim = 1800
n_lidar = 4
position_dim = 2

def StateCallback(msg):
    global lidar_data, goal_position, action_idx, flag_arrival
    for i in range(lidar_dim * n_lidar):
        lidar_data[i] = msg.data[i]
    goal_position[0] = msg.data[lidar_dim * n_lidar + 0]
    goal_position[1] = msg.data[lidar_dim * n_lidar + 1]
    if (goal_position[0] * 6.0 <= 0.3) and (not flag_arrival):
        # print('goal arrived!')
        flag_arrival = True
        vel_cmd = Float32MultiArray(data=[0.0, 0.0])
        pub_cmd_vel.publish(vel_cmd)
    if not flag_arrival:
        action_idx = target_policy.get_action(lidar_data, goal_position)
        world_x = msg.data[lidar_dim * n_lidar + 2]
        world_y = msg.data[lidar_dim * n_lidar + 3]
        world_yaw = msg.data[lidar_dim * n_lidar + 4]
        dy = -action_space[action_idx][0] * time_step
        dx = action_space[action_idx][1] * time_step
        dy_robot = dy * cos(world_yaw) - dx * sin(world_yaw)
        dx_robot = dy * sin(world_yaw) + dx * cos(world_yaw)
        forward_speed = dx_robot / time_step
        side_speed = dy_robot / time_step
        print('command: ', forward_speed, side_speed)
        vel_cmd = Float32MultiArray(data=[forward_speed, side_speed])
        pub_cmd_vel.publish(vel_cmd)

def main():
    sub_robot_states = rospy.Subscriber('/RL_states', Float32MultiArray, StateCallback, queue_size=5)

if __name__ == '__main__':
    rospy.init_node('rl_navigation_test')
    time_step = 0.3
    pub_cmd_vel = rospy.Publisher('/cmd_vel', Float32MultiArray, queue_size=10)
    v_sample_num = 7
    # allocate gpu
    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    gpu_index = 0
    tf.config.experimental.set_visible_devices(devices=gpus[gpu_index], device_type='GPU')
    # tf.config.experimental.set_virtual_device_configuration(gpus[gpu_index], \
    # [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=4096)])
    
    # policy --> map dqn
    target_policy = Lidar_DQN()
    model_weight_file = 'weight_episode_20000.h5'
    target_policy.configure(v_sample_num * v_sample_num) # square of a odd integer
    target_policy.load_model(model_weight_file)
    target_policy.set_lr()
    delta_v = 0.6 / (v_sample_num - 1) # speed from -0.3m/s to 0.3m/s
    v_sample = []
    for i in range(v_sample_num):
        v = -0.3 + delta_v * i
        v_sample.append(v)
    action_space = []
    for vx in v_sample:
        for vy in v_sample:
            action_space.append((vx, vy))
    action_idx = 0

    lidar_data = np.ones(lidar_dim * n_lidar, dtype=np.float32)
    goal_position = np.ones(position_dim, dtype=np.float32)
    flag_arrival = False
    
    main()
    rospy.spin()
#ifndef VELODYNE_LASERSCAN_VELODYNE_LASERSCAN_H
#define VELODYNE_LASERSCAN_VELODYNE_LASERSCAN_H

#include <vector>
#include <cmath>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/Imu.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <geometry_msgs/Quaternion.h>
#include <tf/transform_datatypes.h>
#include <std_msgs/Float32MultiArray.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>

#include <boost/thread/mutex.hpp>
#include <boost/thread/lock_guard.hpp>

#define M_PI_S 3.141592654
#define SIZE 1800
#define RESOLUTION 0.00349
#define MAX_DIST 999.9
#define MAX_SCAN 4.0
#define MIN_SCAN 0.27
#define SCAN_INTERVAL 3

using namespace std;

class VelodyneLaserScan
{
public:
  VelodyneLaserScan(ros::NodeHandle &nh);

  void pub_scan_and_RL_states(const sensor_msgs::LaserScan::ConstPtr& msg);
  void combineCallback(const nav_msgs::Odometry::ConstPtr& msg1, const sensor_msgs::LaserScan::ConstPtr& msg2);

  ros::NodeHandle nh_;
  ros::Publisher pub_RL_states;
  ros::Publisher pub_scan;

  // synchronize all sensors
  typedef message_filters::sync_policies::ApproximateTime<nav_msgs::Odometry, sensor_msgs::LaserScan> SyncPolicy;
  message_filters::Subscriber<nav_msgs::Odometry>* Odom_sub_;   // topic1 input
  message_filters::Subscriber<sensor_msgs::LaserScan>* Lidar_sub_;   // topic2 input
  message_filters::Synchronizer<SyncPolicy>* sync_;

  // used to publish RL_states at a given frequency
  int count = 0;
  // robot pose in the world frame
  float robot_pose_world[3] = {0.0, 0.0, 0.0};
  // goal position in the world frame
  float goal_position[2] = {4.0, 0.0};
  // consecutive 10 Lidar scans
  // the sampling frequency of lidar is 10Hz, the time of consecutive 10 Lidar scans is 0.9 second.
  vector<float> ElevenLidarScansEndPositionWorldX;
  vector<float> ElevenLidarScansEndPositionWorldY;
};


#endif  // VELODYNE_LASERSCAN_VELODYNE_LASERSCAN_H
